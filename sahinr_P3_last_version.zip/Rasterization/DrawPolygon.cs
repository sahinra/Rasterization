﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Rasterization
{
    class DrawPolygon : IDrawnShapes
    {
        public string Name { get; set; } = "Polygon";
        public Color Color { get; set; } = Colors.Red;
        public WriteableBitmap WriteableBitmap { get; set; }

        private List<Point> Points = new List<Point>();

        private List<int> Indices = new List<int>();

        private int[] sortedIndices = { 8, 9, 7, 1, 4, 0, 5, 3, 6, 2 };//new List<int>();

        public int Thickness { get; set; } = 1;

        public struct EdgeTable //active edge table
        {
            int y; //y max, y += 1
            int x; //x of y min, x = x + 1/m
            int slope; // 
        }

        List<EdgeTable> AET = new List<EdgeTable>();

        public DrawPolygon(List<Point> points)
        {
            foreach(Point p in points)
            {
                Points.Add(p);
            }
        }

        public List<Point> GetPoints()
        {
            return Points;
        }

        private void SetIndices()
        {
            foreach(var p in Points)
            {
                Indices.Add((int)p.Y);
            }
            SortIndices(Indices);
        }

        private void SortIndices(List<int> arr)
        {
            //for(int i=0; i<Points.Count; i++)
            //{
            //    sortedIndices.Add(0);
            //}

            //int temp, max;
            //for (int i = 0; i < arr.Count - 1; i++)
            //{
            //    max = i;
            //    for (int j = i + 1; j < arr.Count; j++)
            //    {
            //        if (arr[j] >= arr[max])
            //        {
            //            max = j;
            //        }
            //    }
            //    sortedIndices.Insert(max, i);
            //    temp = arr[max];
            //    arr[max] = arr[i];
            //    arr[i] = temp;
            //}




            //int temp;
            //for (int j = 0; j <= arr.Count - 2; j++)
            //{
            //    for (int i = 0; i <= arr.Count - 2; i++)
            //    {
            //        if (arr[i] > arr[i + 1])
            //        {
            //            temp = arr[i + 1];
            //            arr[i + 1] = arr[i];
            //            arr[i] = temp;
            //        }
            //    }
            //}
            //arr.Reverse();
        }

        public void ApplyModifiedDDA(Color color)
        {
            foreach(var p in Points)
            {
                int index = Points.IndexOf(p);
                if (index == Points.Count - 1)
                {
                    ComputeDDAPoints(Points[0], p, color);
                    return;
                }
                ComputeDDAPoints(p, Points[index + 1], color);
            }
        }

        public void FillPolygon(Color color)
        {
            //SetIndices();

            foreach (var a in sortedIndices)
            {
                Debug.WriteLine(a);
            }

            //int N = Points.Count;
            //int k = 0;
            //int i = sortedIndices[k];
            //int y = (int)Points[sortedIndices[0]].Y, ymin = (int)Points[sortedIndices[0]].Y;
            //int ymax = (int)Points[sortedIndices[N - 1]].Y;
            //while (y < ymax)
            //{
            //    while ((int)Points[i].Y == y)
            //    {
            //        // remember to wrap indices in polygon
            //        if (Points[i ‐ 1].Y > Points[i].Y) AET.Add(Points[i], Points[i‐1]);
            //        if (Points[i + 1].Y > Points[i].Y) AET.Add(Points[i], Points[i + 1]);
            //        ++k;
            //        i = Indices[k];
            //    }
            //    //sort AET by x value
            //    //fill pixels between pairs of intersections
            //    ++y;
            //    if (ymax == y)
            //    {

            //    }
            //    //remove from AET edges for which ymax = y
            //    //for each edge in AET
            //    //x += 1 / m
            //}
        }

        public void DeleteShape()
        {
            Draw(Colors.Black);
        }

        public void Draw(Color color)
        {
            WriteableBitmap.Lock();
            try
            {
                ApplyModifiedDDA(color);
            }
            finally
            {
                WriteableBitmap.Unlock();
            }
        }

        public void EditShape(int x, int y, int index)
        {
            double dx = x - Points[index].X;
            double dy = y - Points[index].Y;

            Point newPoint = new Point
            {
                X = Points[index].X + dx,
                Y = Points[index].Y + dy
            };

            DeleteShape();

            Points.RemoveAt(index);
            Points.Insert(index, newPoint);

            Draw(Color);
        }

        public void MoveShape(int x, int y)
        {
            double dx = x - Points[0].X;
            double dy = y - Points[0].Y;
            List<Point> newPoints = new List<Point>();

            foreach(Point p in Points)
            {
                Point newPoint = new Point
                {
                    X = p.X + dx,
                    Y = p.Y + dy
                };
                newPoints.Add(newPoint);
            }

            DeleteShape();
            Points.Clear();
            
            foreach (Point p in newPoints)
            {
                Points.Add(p);
            }

            Draw(Color);
        }

        void SetPixel(int x, int y, Color color)
        {
            if (y > WriteableBitmap.PixelHeight - 1 || x > WriteableBitmap.PixelWidth - 1)
                return;
            if (y < 0 || x < 0)
                return;

            IntPtr pBackBuffer = WriteableBitmap.BackBuffer;
            int stride = WriteableBitmap.BackBufferStride;

            unsafe
            {
                byte* pBuffer = (byte*)pBackBuffer.ToPointer();
                int location = y * stride + x * 4;

                pBuffer[location] = color.B;
                pBuffer[location + 1] = color.G;
                pBuffer[location + 2] = color.R;
                pBuffer[location + 3] = color.A;

            }
            WriteableBitmap.AddDirtyRect(new Int32Rect(x, y, 1, 1));
        }

        public void ComputeDDAPoints(Point startPoint, Point endPoint, Color color)
        {
            double distanceX = endPoint.X - startPoint.X;
            double distanceY = endPoint.Y - startPoint.Y;
            double step;

            if (Math.Abs(distanceX) > Math.Abs(distanceY))
            {
                step = Math.Abs(distanceX);
            }
            else
            {
                step = Math.Abs(distanceY);
            }

            distanceX = distanceX / step;
            distanceY = distanceY / step;

            for (int i = 1; i <= step; i++)
            {
                if (Thickness <= 3) // 1, 2, 3
                {
                    SetPixel((int)startPoint.X, (int)startPoint.Y, color);
                    SetPixel((int)endPoint.X, (int)endPoint.Y, color);
                    if (Thickness >= 2) // 2, 3
                    {
                        SetPixel((int)startPoint.X + 1, (int)startPoint.Y + 1, color);
                        SetPixel((int)endPoint.X + 1, (int)endPoint.Y + 1, color);
                        if (Thickness == 3) // 3
                        {
                            SetPixel((int)startPoint.X + 2, (int)startPoint.Y + 2, color);
                            SetPixel((int)endPoint.X + 2, (int)endPoint.Y + 2, color);
                        }
                    }
                }

                startPoint.X += distanceX;
                startPoint.Y += distanceY;
            }
        }
    }
}
